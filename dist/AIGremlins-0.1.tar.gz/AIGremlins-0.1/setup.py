from setuptools import setup, find_packages

with open('requirements.txt') as f:
    requirements = f.read().splitlines()

setup(
    name='AIGremlins',
    version='0.1',
    author='Ivan Thung',
    author_email='ivanthung@gmail.com',
    url='https://github.com/ivanthung/AIGremlins',
    description='A package that uses OpenAI to backstop your code',
    packages=find_packages(),
    install_requires=requirements,
)
